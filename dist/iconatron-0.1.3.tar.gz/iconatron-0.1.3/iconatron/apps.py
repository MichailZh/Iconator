from django.apps import AppConfig


class IconatronConfig(AppConfig):
    name = 'iconatron'