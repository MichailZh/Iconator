Iconatron version: 0.0.1

You can install this package from PYPI using pip

    $pip install iconatron
    
