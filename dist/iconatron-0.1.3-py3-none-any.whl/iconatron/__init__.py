from .functions import get_svg

default_app_config = 'iconatron.apps.IconatronConfig'